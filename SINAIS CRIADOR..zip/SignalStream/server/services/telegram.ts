export interface TelegramService {
  sendMessage(botToken: string, chatId: string, message: string): Promise<boolean>;
  testConnection(botToken: string, chatId: string): Promise<boolean>;
}

class TelegramServiceImpl implements TelegramService {
  async sendMessage(botToken: string, chatId: string, message: string): Promise<boolean> {
    const maxRetries = 5;
    let retryCount = 0;
    
    while (retryCount < maxRetries) {
      try {
        const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
        const response = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            chat_id: chatId,
            text: message,
            parse_mode: 'HTML',
          }),
        });

        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        const result = await response.json();
        
        if (result.ok === true) {
          console.log(`✅ Message sent successfully to ${chatId}: ${message.substring(0, 50)}...`);
          return true;
        } else {
          throw new Error(`Telegram API Error: ${result.description || 'Unknown error'}`);
        }
      } catch (error) {
        retryCount++;
        console.error(`❌ Attempt ${retryCount}/${maxRetries} failed for ${chatId}:`, error);
        
        if (retryCount < maxRetries) {
          // Exponential backoff: 1s, 2s, 4s, 8s
          const delay = Math.pow(2, retryCount - 1) * 1000;
          console.log(`⏳ Retrying in ${delay}ms...`);
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }
    }
    
    // If all retries failed, try one last time with a different approach
    try {
      console.log(`🔄 Last attempt with simplified message for ${chatId}`);
      const simplifiedMessage = message.replace(/[^\w\s\-\+\(\)]/g, ''); // Remove special characters
      const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chat_id: chatId,
          text: simplifiedMessage,
        }),
      });

      const result = await response.json();
      if (result.ok === true) {
        console.log(`✅ Message sent with simplified format to ${chatId}`);
        return true;
      }
    } catch (finalError) {
      console.error(`💥 Final attempt failed for ${chatId}:`, finalError);
    }
    
    console.error(`🚫 CRITICAL: Failed to send message after all attempts to ${chatId}: ${message}`);
    return false;
  }

  async testConnection(botToken: string, chatId: string): Promise<boolean> {
    try {
      console.log(`🔧 Testing Telegram connection for bot token: ${botToken.substring(0, 10)}... and chatId: ${chatId}`);
      
      // First, validate bot token by getting bot info
      const botInfoUrl = `https://api.telegram.org/bot${botToken}/getMe`;
      const botResponse = await fetch(botInfoUrl);
      const botResult = await botResponse.json();
      
      if (!botResult.ok) {
        console.error('❌ Bot token is invalid:', botResult);
        return false;
      }
      
      console.log(`✅ Bot token valid: ${botResult.result.first_name} (@${botResult.result.username})`);
      
      // Then test sending message
      const testMessage = `🔧 Teste de conexão\n✅ Bot: ${botResult.result.first_name}\n📅 ${new Date().toLocaleString('pt-BR')}`;
      const success = await this.sendMessage(botToken, chatId, testMessage);
      
      if (success) {
        console.log('✅ Test message sent successfully');
      } else {
        console.error('❌ Test message failed to send');
      }
      
      return success;
    } catch (error) {
      console.error('💥 Error in test connection:', error);
      return false;
    }
  }
}

export const telegramService = new TelegramServiceImpl();
