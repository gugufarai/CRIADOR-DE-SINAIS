import { MemStorage } from '../../server/storage.js';
import { insertSignalRoomSchema } from '../../shared/schema.js';
import TelegramService from '../../server/services/telegram.js';

const storage = new MemStorage();
const telegramService = new TelegramService();

export const handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    if (event.httpMethod === 'GET') {
      const rooms = await storage.getRooms();
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(rooms)
      };
    }

    if (event.httpMethod === 'POST') {
      const body = JSON.parse(event.body);
      console.log('🏗️ Creating new room with data:', body);
      
      // Clean up input data
      const cleanData = {
        ...body,
        botToken: body.botToken?.trim(),
        chatId: body.chatId?.trim(),
        name: body.name?.trim()
      };

      const result = insertSignalRoomSchema.safeParse(cleanData);
      if (!result.success) {
        console.error('❌ Room data validation failed:', result.error.errors);
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ message: "Invalid room data", errors: result.error.errors })
        };
      }

      console.log('✅ Room data validation passed');

      // Test Telegram connection before creating room (skip if chat ID is "test")
      if (result.data.chatId.toLowerCase() !== "test") {
        console.log(`🔧 Testing Telegram connection for room: ${result.data.name}`);
        const connectionTest = await telegramService.testConnection(result.data.botToken, result.data.chatId);
        
        if (!connectionTest) {
          console.error('❌ Telegram connection test failed');
          return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ 
              message: "Falha na conexão com o Telegram. Verifique se:\n1. O token do bot está correto\n2. O bot foi adicionado ao grupo/canal\n3. O Chat ID está correto\n4. O bot tem permissão para enviar mensagens\n\n💡 Use 'test' como Chat ID para testar sem Telegram" 
            })
          };
        }
      } else {
        console.log(`⚠️ Creating test room without Telegram validation for: ${result.data.name}`);
      }

      console.log('✅ Telegram connection test passed');

      const room = await storage.createRoom(result.data);
      console.log('✅ Room created successfully:', room);

      return {
        statusCode: 201,
        headers,
        body: JSON.stringify(room)
      };
    }

    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ message: 'Method not allowed' })
    };

  } catch (error) {
    console.error('❌ Error in rooms function:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ message: 'Internal server error', error: error.message })
    };
  }
};