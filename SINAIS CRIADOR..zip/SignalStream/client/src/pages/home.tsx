import { Signal } from "lucide-react";
import RoomForm from "@/components/room-form";
import RoomCard from "@/components/room-card";
import SignalHistory from "@/components/signal-history";
import GlobalStats from "@/components/global-stats";
import { useQuery } from "@tanstack/react-query";
import type { SignalRoom } from "@shared/schema";

export default function Home() {
  const { data: rooms = [], refetch: refetchRooms } = useQuery<SignalRoom[]>({
    queryKey: ["/api/rooms"],
  });

  const activeRoomsCount = rooms.filter(room => room.active).length;

  return (
    <div className="min-h-screen bg-dark-bg text-text-primary">
      {/* Header */}
      <header className="bg-dark-card border-b border-dark-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-green-accent to-green-400 rounded-lg flex items-center justify-center">
                <Signal className="text-dark-bg text-xl" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-text-primary">Signal Manager</h1>
                <p className="text-sm text-text-secondary">Telegram Rooms Controller</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-accent rounded-full animate-pulse"></div>
                <span className="text-sm text-text-secondary">Online</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Create Room Form */}
          <div className="lg:col-span-1">
            <RoomForm onRoomCreated={refetchRooms} />
          </div>

          {/* Rooms List */}
          <div className="lg:col-span-2">
            <div className="bg-dark-card border border-dark-border rounded-xl p-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-2">
                  <Signal className="text-green-accent" />
                  <h2 className="text-lg font-semibold">Salas Ativas</h2>
                  <span className="bg-green-accent text-dark-bg px-2 py-1 rounded-full text-xs font-medium">
                    {activeRoomsCount}
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-accent rounded-full animate-pulse"></div>
                  <span className="text-sm text-text-secondary">Auto-envio: 30s</span>
                </div>
              </div>

              {rooms.length === 0 ? (
                <div className="text-center py-12">
                  <Signal className="w-12 h-12 text-text-secondary mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-text-primary mb-2">Nenhuma sala criada</h3>
                  <p className="text-text-secondary">Crie sua primeira sala de sinais para começar.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {rooms.map((room) => (
                    <RoomCard key={room.id} room={room} onUpdate={refetchRooms} />
                  ))}
                </div>
              )}
            </div>

            {/* Signal History */}
            <SignalHistory />
          </div>
        </div>

        {/* Global Stats */}
        <GlobalStats />
      </div>
    </div>
  );
}
