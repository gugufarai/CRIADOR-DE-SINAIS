import { MemStorage } from '../../server/storage.js';
import { SignalGenerator } from '../../server/services/signalGenerator.js';
import TelegramService from '../../server/services/telegram.js';

const storage = new MemStorage();
const signalGenerator = new SignalGenerator();
const telegramService = new TelegramService();

export const handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    if (event.httpMethod === 'POST') {
      console.log('📡 Manual signal generation triggered via Netlify function');
      
      const rooms = await storage.getRooms();
      const activeRooms = rooms.filter(room => room.active);
      
      console.log(`📡 Analyzing ${activeRooms.length} active rooms for real signals...`);
      
      if (activeRooms.length === 0) {
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({ message: 'No active rooms to process', generatedSignals: 0 })
        };
      }
      
      let generatedSignals = 0;
      
      for (const room of activeRooms) {
        try {
          // Generate signal based on real market analysis
          const signal = signalGenerator.generateSignal(room);
          console.log(`📊 Generated ${signal.signalType} signal for room ${room.name}:`, signal);
          
          // Store signal in database
          const storedSignal = await storage.createSignal({
            ...signal,
            roomId: room.id
          });
          
          // Send to Telegram if not test room
          if (room.chatId.toLowerCase() !== "test") {
            const success = await telegramService.sendSignal(room, signal);
            console.log(`📤 Signal sent to Telegram for room ${room.name}: ${success ? 'SUCCESS' : 'FAILED'}`);
          } else {
            console.log(`⚠️ Skipping Telegram send for test room: ${room.name}`);
          }
          
          generatedSignals++;
          
        } catch (error) {
          console.error(`❌ Error processing room ${room.name}:`, error);
        }
      }
      
      console.log(`✅ Signal generation completed. Generated ${generatedSignals} signals for ${activeRooms.length} rooms`);
      
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ 
          message: 'Signal generation completed', 
          generatedSignals,
          processedRooms: activeRooms.length 
        })
      };
    }

    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ message: 'Method not allowed' })
    };

  } catch (error) {
    console.error('❌ Error in signal-generator function:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ message: 'Internal server error', error: error.message })
    };
  }
};