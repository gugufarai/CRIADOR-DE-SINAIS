import { type SignalRoom, type InsertSignalRoom, type Signal, type InsertSignal, type MessageTemplates, type InsertMessageTemplates } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Signal Rooms
  getSignalRooms(): Promise<SignalRoom[]>;
  getSignalRoom(id: string): Promise<SignalRoom | undefined>;
  createSignalRoom(room: InsertSignalRoom): Promise<SignalRoom>;
  updateSignalRoom(id: string, updates: Partial<SignalRoom>): Promise<SignalRoom | undefined>;
  deleteSignalRoom(id: string): Promise<boolean>;
  
  // Signals
  getSignals(roomId?: string): Promise<Signal[]>;
  createSignal(signal: InsertSignal): Promise<Signal>;
  updateSignalResult(id: string, result: 'green' | 'red', galesUsed: number): Promise<Signal | undefined>;
  
  // Message Templates
  getMessageTemplates(): Promise<MessageTemplates | undefined>;
  updateMessageTemplates(templates: InsertMessageTemplates): Promise<MessageTemplates>;
}

export class MemStorage implements IStorage {
  private signalRooms: Map<string, SignalRoom>;
  private signals: Map<string, Signal>;
  private messageTemplates: MessageTemplates;

  constructor() {
    this.signalRooms = new Map();
    this.signals = new Map();
    this.messageTemplates = {
      id: "default",
      signalTemplate: "🚀 Novo sinal na sala [NOME]: [SIGNAL]",
      galeTemplate: "⚡ GALE [NUMBER] - [SIGNAL]"
    };
  }

  async getSignalRooms(): Promise<SignalRoom[]> {
    return Array.from(this.signalRooms.values());
  }

  async getSignalRoom(id: string): Promise<SignalRoom | undefined> {
    return this.signalRooms.get(id);
  }

  async createSignalRoom(insertRoom: InsertSignalRoom): Promise<SignalRoom> {
    const id = randomUUID();
    const room: SignalRoom = {
      ...insertRoom,
      id,
      gales: insertRoom.gales ?? 0,
      active: insertRoom.active ?? true,
      messageTemplate: insertRoom.messageTemplate ?? null,
      galeTemplate: insertRoom.galeTemplate ?? null,
      minesAttempts: insertRoom.minesAttempts ?? 3,
      createdAt: new Date(),
    };
    this.signalRooms.set(id, room);
    return room;
  }

  async updateSignalRoom(id: string, updates: Partial<SignalRoom>): Promise<SignalRoom | undefined> {
    const room = this.signalRooms.get(id);
    if (!room) return undefined;
    
    const updatedRoom = { ...room, ...updates };
    this.signalRooms.set(id, updatedRoom);
    return updatedRoom;
  }

  async deleteSignalRoom(id: string): Promise<boolean> {
    return this.signalRooms.delete(id);
  }

  async getSignals(roomId?: string): Promise<Signal[]> {
    const allSignals = Array.from(this.signals.values());
    if (roomId) {
      return allSignals.filter(signal => signal.roomId === roomId);
    }
    return allSignals.sort((a, b) => new Date(b.timestamp!).getTime() - new Date(a.timestamp!).getTime());
  }

  async createSignal(insertSignal: InsertSignal): Promise<Signal> {
    const id = randomUUID();
    const signal: Signal = {
      ...insertSignal,
      id,
      result: insertSignal.result ?? null,
      galesUsed: insertSignal.galesUsed ?? null,
      metadata: insertSignal.metadata ?? null,
      timestamp: new Date(),
    };
    this.signals.set(id, signal);
    return signal;
  }

  async updateSignalResult(id: string, result: 'green' | 'red', galesUsed: number): Promise<Signal | undefined> {
    const signal = this.signals.get(id);
    if (!signal) return undefined;
    
    const updatedSignal = { ...signal, result, galesUsed };
    this.signals.set(id, updatedSignal);
    return updatedSignal;
  }

  async getMessageTemplates(): Promise<MessageTemplates | undefined> {
    return this.messageTemplates;
  }

  async updateMessageTemplates(templates: InsertMessageTemplates): Promise<MessageTemplates> {
    this.messageTemplates = { ...this.messageTemplates, ...templates };
    return this.messageTemplates;
  }
}

export const storage = new MemStorage();
