// Função CRON para gerar sinais automaticamente a cada 30 segundos
// Netlify permite agendar funções via webhooks externos ou serviços como cron-job.org

import { MemStorage } from '../../server/storage.js';
import { SignalGenerator } from '../../server/services/signalGenerator.js';
import TelegramService from '../../server/services/telegram.js';

const storage = new MemStorage();
const signalGenerator = new SignalGenerator();
const telegramService = new TelegramService();

export const handler = async (event, context) => {
  // Verificar se a requisição vem de um serviço autorizado (opcional)
  const authHeader = event.headers.authorization || event.headers.Authorization;
  const expectedAuth = process.env.CRON_SECRET || 'signal-generator-cron-2024';
  
  if (authHeader !== `Bearer ${expectedAuth}`) {
    console.log('❌ Unauthorized cron request');
    return {
      statusCode: 401,
      body: JSON.stringify({ error: 'Unauthorized' })
    };
  }

  const headers = {
    'Content-Type': 'application/json'
  };

  try {
    console.log('🕐 CRON: Starting automatic signal generation...', new Date().toISOString());
    
    const rooms = await storage.getRooms();
    const activeRooms = rooms.filter(room => room.active);
    
    console.log(`📡 CRON: Analyzing ${activeRooms.length} active rooms for real signals...`);
    
    if (activeRooms.length === 0) {
      console.log('📭 CRON: No active rooms found');
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ 
          message: 'CRON completed - no active rooms', 
          timestamp: new Date().toISOString(),
          generatedSignals: 0 
        })
      };
    }
    
    let generatedSignals = 0;
    let successfulSends = 0;
    
    for (const room of activeRooms) {
      try {
        // Generate signal based on real market analysis
        const signal = signalGenerator.generateSignal(room);
        console.log(`📊 CRON: Generated ${signal.signalType} signal for room ${room.name}:`, {
          signal: signal.signal,
          confidence: signal.confidence,
          galeLevel: signal.galeLevel
        });
        
        // Store signal in database
        const storedSignal = await storage.createSignal({
          ...signal,
          roomId: room.id
        });
        
        // Send to Telegram if not test room
        if (room.chatId.toLowerCase() !== "test") {
          const success = await telegramService.sendSignal(room, signal);
          if (success) {
            successfulSends++;
          }
          console.log(`📤 CRON: Signal sent to Telegram for room ${room.name}: ${success ? 'SUCCESS' : 'FAILED'}`);
        } else {
          console.log(`⚠️ CRON: Skipping Telegram send for test room: ${room.name}`);
          successfulSends++; // Count test rooms as successful
        }
        
        generatedSignals++;
        
      } catch (error) {
        console.error(`❌ CRON: Error processing room ${room.name}:`, error);
      }
    }
    
    console.log(`✅ CRON: Signal generation completed. Generated ${generatedSignals} signals for ${activeRooms.length} rooms. ${successfulSends} successful sends.`);
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ 
        message: 'CRON signal generation completed successfully',
        timestamp: new Date().toISOString(),
        generatedSignals,
        processedRooms: activeRooms.length,
        successfulSends,
        nextRun: 'In 30 seconds'
      })
    };

  } catch (error) {
    console.error('❌ CRON: Error in automatic signal generation:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        error: 'CRON signal generation failed', 
        message: error.message,
        timestamp: new Date().toISOString()
      })
    };
  }
};