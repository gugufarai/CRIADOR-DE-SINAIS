import { History } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import type { Signal, SignalRoom } from "@shared/schema";

interface SignalWithRoom extends Signal {
  room?: SignalRoom;
}

export default function SignalHistory() {
  const { data: signals = [] } = useQuery<Signal[]>({
    queryKey: ["/api/signals"],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const { data: rooms = [] } = useQuery<SignalRoom[]>({
    queryKey: ["/api/rooms"],
  });

  // Combine signals with room data
  const signalsWithRooms: SignalWithRoom[] = signals.map(signal => ({
    ...signal,
    room: rooms.find(room => room.id === signal.roomId)
  }));

  const formatTime = (timestamp: Date | null) => {
    if (!timestamp) return 'N/A';
    return new Date(timestamp).toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  return (
    <Card className="bg-dark-card border-dark-border mt-6">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2 text-text-primary">
          <History className="text-green-accent" />
          <span>Histórico de Sinais</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {signalsWithRooms.length === 0 ? (
          <div className="text-center py-8">
            <History className="w-12 h-12 text-text-secondary mx-auto mb-4" />
            <h3 className="text-lg font-medium text-text-primary mb-2">Nenhum sinal enviado</h3>
            <p className="text-text-secondary">Os sinais aparecerão aqui conforme forem enviados.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-dark-border">
                  <th className="text-left py-3 text-sm font-medium text-text-secondary">Sala</th>
                  <th className="text-left py-3 text-sm font-medium text-text-secondary">Sinal</th>
                  <th className="text-left py-3 text-sm font-medium text-text-secondary">Resultado</th>
                  <th className="text-left py-3 text-sm font-medium text-text-secondary">Gales</th>
                  <th className="text-left py-3 text-sm font-medium text-text-secondary">Horário</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-dark-border">
                {signalsWithRooms.slice(0, 10).map((signal) => (
                  <tr key={signal.id} className="hover:bg-dark-bg transition-colors" data-testid={`signal-row-${signal.id}`}>
                    <td className="py-3">
                      <span className="text-text-primary font-medium" data-testid={`text-signal-room-${signal.id}`}>
                        {signal.room?.name || 'Sala Desconhecida'}
                      </span>
                    </td>
                    <td className="py-3">
                      <span className="text-text-primary" data-testid={`text-signal-value-${signal.id}`}>
                        {signal.signalValue}
                      </span>
                    </td>
                    <td className="py-3">
                      {signal.result ? (
                        <Badge 
                          variant={signal.result === 'green' ? 'default' : 'destructive'}
                          className={signal.result === 'green' ? 
                            "bg-green-accent bg-opacity-20 text-green-accent" : 
                            "bg-red-accent bg-opacity-20 text-red-accent"}
                          data-testid={`badge-signal-result-${signal.id}`}
                        >
                          {signal.result.toUpperCase()}
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="text-text-secondary" data-testid={`badge-signal-pending-${signal.id}`}>
                          PENDENTE
                        </Badge>
                      )}
                    </td>
                    <td className="py-3">
                      <span className="text-text-secondary" data-testid={`text-signal-gales-${signal.id}`}>
                        {signal.galesUsed || 0}
                      </span>
                    </td>
                    <td className="py-3">
                      <span className="text-text-secondary text-sm" data-testid={`text-signal-time-${signal.id}`}>
                        {formatTime(signal.timestamp)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
