import { useState } from "react";
import { Plus, Edit, Search, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { InsertSignalRoom, MessageTemplates } from "@shared/schema";

interface RoomFormProps {
  onRoomCreated: () => void;
}

export default function RoomForm({ onRoomCreated }: RoomFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState<InsertSignalRoom>({
    name: "",
    botToken: "",
    chatId: "",
    signalType: "",
    gales: 0,
    active: true,
    messageTemplate: null,
    galeTemplate: null,
    minesAttempts: 3,
  });

  const [templates, setTemplates] = useState({
    signalTemplate: "🚀 Novo sinal na sala [NOME]: [SIGNAL]",
    galeTemplate: "⚡ GALE [NUMBER] - [SIGNAL]",
  });

  const { data: existingTemplates } = useQuery<MessageTemplates>({
    queryKey: ["/api/templates"],
  });

  const createRoomMutation = useMutation({
    mutationFn: async (data: InsertSignalRoom) => {
      const response = await apiRequest("POST", "/api/rooms", data);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Sala criada com sucesso!" });
      setFormData({
        name: "",
        botToken: "",
        chatId: "",
        signalType: "",
        gales: 0,
        active: true,
        messageTemplate: null,
        galeTemplate: null,
        minesAttempts: 3,
      });
      onRoomCreated();
      queryClient.invalidateQueries({ queryKey: ["/api/rooms"] });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao criar sala",
        description: error.message || "Verifique os dados e tente novamente",
        variant: "destructive",
      });
    },
  });

  const [loadingChatIds, setLoadingChatIds] = useState(false);
  const [availableChats, setAvailableChats] = useState<any[]>([]);

  const updateTemplatesMutation = useMutation({
    mutationFn: async (data: { signalTemplate: string; galeTemplate: string }) => {
      const response = await apiRequest("PUT", "/api/templates", data);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Templates salvos com sucesso!" });
      queryClient.invalidateQueries({ queryKey: ["/api/templates"] });
    },
    onError: () => {
      toast({
        title: "Erro ao salvar templates",
        variant: "destructive",
      });
    },
  });

  const findChatIdsMutation = useMutation({
    mutationFn: async (botToken: string) => {
      const response = await apiRequest("POST", "/api/telegram/getUpdates", { botToken });
      return response.json();
    },
    onSuccess: (data) => {
      setAvailableChats(data.chats || []);
      toast({ title: `Encontrados ${data.chats?.length || 0} chats disponíveis` });
    },
    onError: () => {
      toast({
        title: "Erro ao buscar chats",
        description: "Verifique se o token do bot está correto",
        variant: "destructive",
      });
    },
  });

  const handleFindChatIds = () => {
    if (!formData.botToken) {
      toast({
        title: "Token necessário",
        description: "Insira o token do bot primeiro",
        variant: "destructive",
      });
      return;
    }
    
    setLoadingChatIds(true);
    findChatIdsMutation.mutate(formData.botToken);
    setLoadingChatIds(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.botToken || !formData.chatId || !formData.signalType) {
      toast({
        title: "Preencha todos os campos obrigatórios",
        variant: "destructive",
      });
      return;
    }

    createRoomMutation.mutate(formData);
  };

  const handleSaveTemplates = (e: React.FormEvent) => {
    e.preventDefault();
    updateTemplatesMutation.mutate(templates);
  };

  return (
    <div className="space-y-6">
      {/* Create Room Form */}
      <Card className="bg-dark-card border-dark-border">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-text-primary">
            <Plus className="text-green-accent" />
            <span>Criar Nova Sala</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="name" className="text-text-secondary">Nome da Sala</Label>
              <Input
                id="name"
                data-testid="input-room-name"
                placeholder="Ex: VIP Signals"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-dark-bg border-dark-border text-text-primary placeholder:text-text-secondary focus:border-green-accent focus:ring-green-accent"
              />
            </div>

            <div>
              <Label htmlFor="botToken" className="text-text-secondary">Token do Bot</Label>
              <Input
                id="botToken"
                data-testid="input-bot-token"
                type="password"
                placeholder="1234567890:ABCdefGHIjklMNOpqrsTUVwxyz"
                value={formData.botToken}
                onChange={(e) => setFormData({ ...formData, botToken: e.target.value })}
                className="bg-dark-bg border-dark-border text-text-primary placeholder:text-text-secondary focus:border-green-accent focus:ring-green-accent font-mono text-sm"
              />
            </div>

            <div>
              <Label htmlFor="chatId" className="text-text-secondary">Chat ID</Label>
              <div className="space-y-2">
                <Input
                  id="chatId"
                  data-testid="input-chat-id"
                  placeholder="-1001234567890"
                  value={formData.chatId}
                  onChange={(e) => setFormData({ ...formData, chatId: e.target.value })}
                  className="bg-dark-bg border-dark-border text-text-primary placeholder:text-text-secondary focus:border-green-accent focus:ring-green-accent font-mono"
                />
                <div className="flex space-x-2">
                  <Button
                    type="button"
                    onClick={handleFindChatIds}
                    disabled={loadingChatIds || findChatIdsMutation.isPending || !formData.botToken}
                    className="bg-orange-accent hover:bg-orange-400 text-dark-bg"
                    size="sm"
                    data-testid="button-find-chat-ids"
                  >
                    <Search className="mr-1 h-3 w-3" />
                    {findChatIdsMutation.isPending ? "Buscando..." : "Buscar Chat IDs"}
                  </Button>
                </div>

                {availableChats.length > 0 && (
                  <div className="bg-dark-card border border-dark-border rounded-lg p-3 space-y-2">
                    <h4 className="text-sm font-medium text-green-accent">Chats Encontrados:</h4>
                    {availableChats.map((chat, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-2 bg-dark-bg rounded cursor-pointer hover:bg-dark-border transition-colors"
                        onClick={() => setFormData({ ...formData, chatId: chat.id.toString() })}
                      >
                        <div>
                          <div className="text-sm font-medium text-text-primary">{chat.title}</div>
                          <div className="text-xs text-text-secondary">
                            {chat.type} • {chat.date}
                          </div>
                        </div>
                        <code className="text-xs font-mono text-green-accent bg-dark-card px-2 py-1 rounded">
                          {chat.id}
                        </code>
                      </div>
                    ))}
                  </div>
                )}

                <Alert className="bg-dark-bg border-orange-accent/30">
                  <Info className="h-4 w-4 text-orange-accent" />
                  <AlertDescription className="text-sm text-text-secondary">
                    <strong className="text-orange-accent">Como obter o Chat ID:</strong><br />
                    1. Adicione o bot @IMPERIOGREEFREBOT ao seu grupo/canal<br />
                    2. Envie uma mensagem no grupo mencionando o bot<br />
                    3. Clique em "Buscar Chat IDs" acima para encontrar automaticamente<br />
                    <br />
                    <strong className="text-green-accent">💡 Para teste:</strong> Use "test" como Chat ID para criar sala de demonstração
                  </AlertDescription>
                </Alert>
              </div>
            </div>

            <div>
              <Label htmlFor="signalType" className="text-text-secondary">Tipo de Sinal</Label>
              <Select onValueChange={(value) => setFormData({ ...formData, signalType: value })}>
                <SelectTrigger data-testid="select-signal-type" className="bg-dark-bg border-dark-border text-text-primary focus:border-green-accent focus:ring-green-accent">
                  <SelectValue placeholder="Selecione o tipo" />
                </SelectTrigger>
                <SelectContent className="bg-dark-card border-dark-border">
                  <SelectItem value="bacbo">Bac Bo</SelectItem>
                  <SelectItem value="mines">Mines</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="gales" className="text-text-secondary">Quantidade de Gales</Label>
              <Select onValueChange={(value) => setFormData({ ...formData, gales: parseInt(value) })}>
                <SelectTrigger data-testid="select-gales" className="bg-dark-bg border-dark-border text-text-primary focus:border-green-accent focus:ring-green-accent">
                  <SelectValue placeholder="Selecione gales" />
                </SelectTrigger>
                <SelectContent className="bg-dark-card border-dark-border">
                  <SelectItem value="0">Sem Gale</SelectItem>
                  <SelectItem value="1">1 Gale</SelectItem>
                  <SelectItem value="2">2 Gales</SelectItem>
                  <SelectItem value="3">3 Gales</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {formData.signalType === 'mines' && (
              <div>
                <Label htmlFor="minesAttempts" className="text-text-secondary">Tentativas para Mines</Label>
                <Select onValueChange={(value) => setFormData({ ...formData, minesAttempts: parseInt(value) })}>
                  <SelectTrigger data-testid="select-mines-attempts" className="bg-dark-bg border-dark-border text-text-primary focus:border-green-accent focus:ring-green-accent">
                    <SelectValue placeholder="Selecione tentativas" />
                  </SelectTrigger>
                  <SelectContent className="bg-dark-card border-dark-border">
                    <SelectItem value="1">1 Tentativa</SelectItem>
                    <SelectItem value="2">2 Tentativas</SelectItem>
                    <SelectItem value="3">3 Tentativas</SelectItem>
                    <SelectItem value="4">4 Tentativas</SelectItem>
                    <SelectItem value="5">5 Tentativas</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}

            <Button 
              type="submit"
              data-testid="button-create-room"
              disabled={createRoomMutation.isPending}
              className="w-full bg-green-accent hover:bg-green-400 text-dark-bg font-semibold"
            >
              <Plus className="mr-2 h-4 w-4" />
              {createRoomMutation.isPending ? "Criando..." : "Criar Sala"}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Message Templates */}
      <Card className="bg-dark-card border-dark-border">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-text-primary">
            <Edit className="text-orange-accent" />
            <span>Templates de Mensagem</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSaveTemplates} className="space-y-4">
            <div>
              <Label htmlFor="signalTemplate" className="text-text-secondary">Mensagem de Sinal</Label>
              <Textarea
                id="signalTemplate"
                data-testid="textarea-signal-template"
                placeholder="🚀 Novo sinal na sala [NOME]: [SIGNAL]"
                value={templates.signalTemplate}
                onChange={(e) => setTemplates({ ...templates, signalTemplate: e.target.value })}
                className="bg-dark-bg border-dark-border text-text-primary placeholder:text-text-secondary focus:border-orange-accent focus:ring-orange-accent h-20 resize-none"
              />
            </div>
            
            <div>
              <Label htmlFor="galeTemplate" className="text-text-secondary">Mensagem de Gale</Label>
              <Textarea
                id="galeTemplate"
                data-testid="textarea-gale-template"
                placeholder="⚡ GALE [NUMBER] - [SIGNAL]"
                value={templates.galeTemplate}
                onChange={(e) => setTemplates({ ...templates, galeTemplate: e.target.value })}
                className="bg-dark-bg border-dark-border text-text-primary placeholder:text-text-secondary focus:border-orange-accent focus:ring-orange-accent h-20 resize-none"
              />
            </div>

            <Button
              type="submit"
              data-testid="button-save-templates"
              disabled={updateTemplatesMutation.isPending}
              className="w-full bg-orange-accent hover:bg-orange-400 text-dark-bg font-semibold"
            >
              {updateTemplatesMutation.isPending ? "Salvando..." : "Salvar Templates"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
