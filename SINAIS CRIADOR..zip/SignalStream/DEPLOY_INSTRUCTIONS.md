# Deploy no Netlify - Signal Manager 🚀

Este sistema foi adaptado para rodar 24/7 no Netlify usando funções serverless.

## 🚀 Passos para Deploy

### 1. Conectar ao Netlify
1. Acesse https://app.netlify.com
2. Conecte seu repositório GitHub
3. Configurar build settings:
   - **Build command**: `npm run build`
   - **Publish directory**: `dist`

### 2. Configurar Variáveis de Ambiente
No painel do Netlify > Site settings > Environment variables, adicione:

```
CRON_SECRET=signal-generator-cron-2024
NODE_ENV=production
```

### 3. Configurar CRON 24/7 (IMPORTANTE!)
Para manter os sinais rodando a cada 30 segundos, configure em https://cron-job.org:

**URL do CRON**: `https://SEU-SITE.netlify.app/.netlify/functions/cron-signal-generator`

**Headers**:
```
Authorization: Bearer signal-generator-cron-2024
Content-Type: application/json
```

**Schedule**: `*/30 * * * * *` (a cada 30 segundos)

**Method**: POST

### 4. URLs das Funções Serverless

Após o deploy, suas funções estarão disponíveis em:

- **Criar Salas**: `/.netlify/functions/rooms`
- **Buscar Sinais**: `/.netlify/functions/signals`  
- **Estatísticas**: `/.netlify/functions/stats`
- **Templates**: `/.netlify/functions/templates`
- **Buscar Chat IDs**: `/.netlify/functions/telegram-find-chats`
- **Gerador Manual**: `/.netlify/functions/signal-generator`
- **CRON Automático**: `/.netlify/functions/cron-signal-generator`

## 🔧 Funcionalidades Mantidas

✅ **Sinais Reais** - Baseados em análise de mercado, nunca simulados
✅ **Garantia de Entrega** - Sistema de retry com 5 tentativas
✅ **Mines Configurável** - Suporte a 1-5 tentativas do jogador
✅ **Chat ID Automático** - Detecção automática via bot do Telegram
✅ **Interface Hacker** - Design dark com tema verde/laranja
✅ **24/7 Operação** - Funcionamento contínuo via CRON externo

## 🎯 Como Funciona no Netlify

1. **Frontend** → Servido estaticamente pelo Netlify
2. **Funções API** → Executam via serverless functions
3. **Armazenamento** → In-memory para cada execução da função
4. **CRON Externo** → Aciona geração de sinais a cada 30 segundos
5. **Telegram** → Envia mensagens com garantia de entrega

## ⚠️ Importante

- O armazenamento é **in-memory** (reinicia a cada cold start)
- Para persistência, considere integrar com banco de dados externo
- O CRON externo é essencial para funcionamento 24/7
- Teste primeiro com Chat ID "test" antes de usar grupos reais

## 🎮 Testando Após Deploy

1. Acesse seu site `https://SEU-SITE.netlify.app`
2. Crie uma sala de teste:
   - Token: `7744444671:AAFumiLkH7lWIcK4DUq9BkqPIxYrpaafNaE`
   - Chat ID: `test`
   - Nome: `Teste Netlify`
3. Configure o CRON e aguarde os sinais serem gerados automaticamente

## 🏆 Pronto!

Seu sistema de sinais agora roda 24/7 no Netlify com todas as funcionalidades originais mantidas!