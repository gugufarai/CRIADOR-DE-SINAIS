import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertSignalRoomSchema, insertMessageTemplatesSchema } from "@shared/schema";
import { signalGenerator } from "./services/signalGenerator";
import { telegramService } from "./services/telegram";

export async function registerRoutes(app: Express): Promise<Server> {
  // Start signal generator
  signalGenerator.start();

  // Get all signal rooms
  app.get("/api/rooms", async (req, res) => {
    try {
      const rooms = await storage.getSignalRooms();
      res.json(rooms);
    } catch (error) {
      res.status(500).json({ message: "Failed to get rooms" });
    }
  });

  // Create signal room
  app.post("/api/rooms", async (req, res) => {
    try {
      console.log('🏗️ Creating new room with data:', req.body);
      
      // Clean up input data
      const cleanData = {
        ...req.body,
        botToken: req.body.botToken?.trim(),
        chatId: req.body.chatId?.trim(),
        name: req.body.name?.trim()
      };

      const result = insertSignalRoomSchema.safeParse(cleanData);
      if (!result.success) {
        console.error('❌ Room data validation failed:', result.error.errors);
        return res.status(400).json({ message: "Invalid room data", errors: result.error.errors });
      }

      console.log('✅ Room data validation passed');

      // Test Telegram connection before creating room (skip if chat ID is "test")
      if (result.data.chatId.toLowerCase() !== "test") {
        console.log(`🔧 Testing Telegram connection for room: ${result.data.name}`);
        const connectionTest = await telegramService.testConnection(result.data.botToken, result.data.chatId);
        
        if (!connectionTest) {
          console.error('❌ Telegram connection test failed');
          return res.status(400).json({ 
            message: "Falha na conexão com o Telegram. Verifique se:\n1. O token do bot está correto\n2. O bot foi adicionado ao grupo/canal\n3. O Chat ID está correto\n4. O bot tem permissão para enviar mensagens\n\n💡 Use 'test' como Chat ID para testar sem Telegram" 
          });
        }
      } else {
        console.log(`⚠️ Creating test room without Telegram validation for: ${result.data.name}`);
      }

      console.log('✅ Telegram connection test passed');

      const room = await storage.createSignalRoom(result.data);
      console.log(`✅ Room created successfully: ${room.name} (${room.id})`);
      
      res.json(room);
    } catch (error) {
      console.error('💥 Error creating room:', error);
      res.status(500).json({ message: "Failed to create room" });
    }
  });

  // Update signal room
  app.patch("/api/rooms/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const room = await storage.updateSignalRoom(id, req.body);
      if (!room) {
        return res.status(404).json({ message: "Room not found" });
      }
      res.json(room);
    } catch (error) {
      res.status(500).json({ message: "Failed to update room" });
    }
  });

  // Delete signal room
  app.delete("/api/rooms/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const success = await storage.deleteSignalRoom(id);
      if (!success) {
        return res.status(404).json({ message: "Room not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete room" });
    }
  });

  // Send test signal
  app.post("/api/rooms/:id/test", async (req, res) => {
    try {
      const { id } = req.params;
      const success = await signalGenerator.sendTestSignal(id);
      if (!success) {
        return res.status(400).json({ message: "Failed to send test signal" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to send test signal" });
    }
  });

  // Get signals
  app.get("/api/signals", async (req, res) => {
    try {
      const { roomId } = req.query;
      const signals = await storage.getSignals(roomId as string);
      res.json(signals);
    } catch (error) {
      res.status(500).json({ message: "Failed to get signals" });
    }
  });

  // Get room statistics
  app.get("/api/rooms/:id/stats", async (req, res) => {
    try {
      const { id } = req.params;
      const signals = await storage.getSignals(id);
      
      const greenCount = signals.filter(s => s.result === 'green').length;
      const redCount = signals.filter(s => s.result === 'red').length;
      const totalCompleted = greenCount + redCount;
      const accuracy = totalCompleted > 0 ? Math.round((greenCount / totalCompleted) * 100) : 0;
      
      const lastSignal = signals[0];
      const lastSignalTime = lastSignal ? new Date(lastSignal.timestamp!) : null;
      const minutesAgo = lastSignalTime ? Math.floor((Date.now() - lastSignalTime.getTime()) / 60000) : null;

      res.json({
        green: greenCount,
        red: redCount,
        accuracy,
        lastSignal: minutesAgo ? `${minutesAgo}m` : 'N/A'
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get room stats" });
    }
  });

  // Get global statistics
  app.get("/api/stats/global", async (req, res) => {
    try {
      const rooms = await storage.getSignalRooms();
      const allSignals = await storage.getSignals();
      
      const activeRooms = rooms.filter(r => r.active).length;
      const totalSignals = allSignals.length;
      
      const greenCount = allSignals.filter(s => s.result === 'green').length;
      const redCount = allSignals.filter(s => s.result === 'red').length;
      const totalCompleted = greenCount + redCount;
      const overallAccuracy = totalCompleted > 0 ? Math.round((greenCount / totalCompleted) * 100) : 0;

      res.json({
        totalRooms: activeRooms,
        totalSignals,
        overallAccuracy,
        uptime: '24h' // This could be calculated from service start time
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get global stats" });
    }
  });

  // Get message templates
  app.get("/api/templates", async (req, res) => {
    try {
      const templates = await storage.getMessageTemplates();
      res.json(templates);
    } catch (error) {
      res.status(500).json({ message: "Failed to get templates" });
    }
  });

  // Update message templates
  app.put("/api/templates", async (req, res) => {
    try {
      const result = insertMessageTemplatesSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: "Invalid template data", errors: result.error.errors });
      }

      const templates = await storage.updateMessageTemplates(result.data);
      res.json(templates);
    } catch (error) {
      res.status(500).json({ message: "Failed to update templates" });
    }
  });

  // Get chat updates to help find chat ID
  app.post("/api/telegram/getUpdates", async (req, res) => {
    try {
      const { botToken } = req.body;
      
      if (!botToken) {
        return res.status(400).json({ message: "Bot token is required" });
      }

      console.log(`🔍 Getting updates for bot token: ${botToken.substring(0, 10)}...`);
      
      const url = `https://api.telegram.org/bot${botToken}/getUpdates`;
      const response = await fetch(url);
      const result = await response.json();
      
      if (!result.ok) {
        console.error('❌ Failed to get updates:', result);
        return res.status(400).json({ message: "Failed to get updates. Check your bot token." });
      }

      // Extract unique chat IDs and info
      const chats = new Map();
      
      result.result.forEach((update: any) => {
        if (update.message && update.message.chat) {
          const chat = update.message.chat;
          const chatKey = chat.id.toString();
          
          if (!chats.has(chatKey)) {
            chats.set(chatKey, {
              id: chat.id,
              type: chat.type,
              title: chat.title || chat.first_name || 'Unknown',
              username: chat.username,
              lastMessage: update.message.text || update.message.caption || '[Media]',
              date: new Date(update.message.date * 1000).toLocaleString('pt-BR')
            });
          }
        }
      });

      const chatList = Array.from(chats.values());
      console.log(`✅ Found ${chatList.length} chats`);
      
      res.json({
        success: true,
        chats: chatList,
        totalUpdates: result.result.length
      });
    } catch (error) {
      console.error('💥 Error getting updates:', error);
      res.status(500).json({ message: "Failed to get updates" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
