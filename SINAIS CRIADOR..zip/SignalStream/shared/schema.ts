import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const signalRooms = pgTable("signal_rooms", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  botToken: text("bot_token").notNull(),
  chatId: text("chat_id").notNull(),
  signalType: text("signal_type").notNull(), // 'bacbo' | 'mines'
  gales: integer("gales").notNull().default(0),
  active: boolean("active").notNull().default(true),
  messageTemplate: text("message_template"),
  galeTemplate: text("gale_template"),
  minesAttempts: integer("mines_attempts").default(3), // For mines: number of attempts player gets
  createdAt: timestamp("created_at").defaultNow(),
});

export const signals = pgTable("signals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roomId: varchar("room_id").references(() => signalRooms.id).notNull(),
  signalValue: text("signal_value").notNull(),
  result: text("result"), // 'green' | 'red' | null
  galesUsed: integer("gales_used").default(0),
  timestamp: timestamp("timestamp").defaultNow(),
  metadata: jsonb("metadata"), // For storing additional signal data
});

export const messageTemplates = pgTable("message_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  signalTemplate: text("signal_template").notNull().default("🚀 Novo sinal na sala [NOME]: [SIGNAL]"),
  galeTemplate: text("gale_template").notNull().default("⚡ GALE [NUMBER] - [SIGNAL]"),
});

export const insertSignalRoomSchema = createInsertSchema(signalRooms).omit({
  id: true,
  createdAt: true,
});

export const insertSignalSchema = createInsertSchema(signals).omit({
  id: true,
  timestamp: true,
});

export const insertMessageTemplatesSchema = createInsertSchema(messageTemplates).omit({
  id: true,
});

export type SignalRoom = typeof signalRooms.$inferSelect;
export type InsertSignalRoom = z.infer<typeof insertSignalRoomSchema>;
export type Signal = typeof signals.$inferSelect;
export type InsertSignal = z.infer<typeof insertSignalSchema>;
export type MessageTemplates = typeof messageTemplates.$inferSelect;
export type InsertMessageTemplates = z.infer<typeof insertMessageTemplatesSchema>;
