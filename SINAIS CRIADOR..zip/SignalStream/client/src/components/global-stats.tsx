import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";

interface GlobalStats {
  totalRooms: number;
  totalSignals: number;
  overallAccuracy: number;
  uptime: string;
}

export default function GlobalStats() {
  const { data: stats } = useQuery<GlobalStats>({
    queryKey: ["/api/stats/global"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const statCards = [
    {
      label: "Salas Ativas",
      value: stats?.totalRooms || 0,
      color: "text-green-accent",
      testId: "stat-total-rooms"
    },
    {
      label: "Sinais Enviados", 
      value: stats?.totalSignals || 0,
      color: "text-text-primary",
      testId: "stat-total-signals"
    },
    {
      label: "Assertividade Geral",
      value: `${stats?.overallAccuracy || 0}%`,
      color: "text-green-accent",
      testId: "stat-overall-accuracy"
    },
    {
      label: "Tempo Online",
      value: stats?.uptime || "0h",
      color: "text-orange-accent",
      testId: "stat-uptime"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mt-8">
      {statCards.map((stat, index) => (
        <Card key={index} className="bg-dark-card border-dark-border">
          <CardContent className="p-6 text-center">
            <div className={`text-3xl font-bold ${stat.color} mb-2`} data-testid={stat.testId}>
              {stat.value}
            </div>
            <div className="text-sm text-text-secondary">{stat.label}</div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
