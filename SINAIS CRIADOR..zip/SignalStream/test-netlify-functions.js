// Script para testar as funções Netlify localmente
import fs from 'fs';
import path from 'path';

// Mock do contexto Netlify
const mockContext = {
  functionName: 'test',
  functionVersion: '1',
  memoryLimitInMB: '128',
  requestId: 'test-request-id',
};

// Mock do evento para testar rooms
const mockEventRooms = {
  httpMethod: 'POST',
  headers: {
    'content-type': 'application/json'
  },
  body: JSON.stringify({
    name: 'Teste Netlify Function',
    botToken: '7744444671:AAFumiLkH7lWIcK4DUq9BkqPIxYrpaafNaE',
    chatId: 'test',
    signalType: 'bacbo',
    gales: 1,
    active: true
  })
};

// Mock do evento para testar signals
const mockEventSignals = {
  httpMethod: 'GET',
  headers: {},
  body: null
};

// Mock do evento para testar cron
const mockEventCron = {
  httpMethod: 'POST',
  headers: {
    authorization: 'Bearer signal-generator-cron-2024'
  },
  body: JSON.stringify({})
};

async function testFunction(functionPath, event, functionName) {
  try {
    console.log(`\n🧪 Testing ${functionName}...`);
    
    // Import dynamic da função
    const { handler } = await import(functionPath);
    
    // Executar função
    const result = await handler(event, mockContext);
    
    console.log(`✅ ${functionName} Status:`, result.statusCode);
    console.log(`📄 ${functionName} Response:`, JSON.parse(result.body || '{}'));
    
    return result;
    
  } catch (error) {
    console.error(`❌ Error testing ${functionName}:`, error);
    return { statusCode: 500, error: error.message };
  }
}

async function runTests() {
  console.log('🚀 Starting Netlify Functions Tests...\n');
  
  // Testar função de rooms
  await testFunction('./netlify/functions/rooms.js', mockEventRooms, 'Rooms');
  
  // Testar função de signals
  await testFunction('./netlify/functions/signals.js', mockEventSignals, 'Signals');
  
  // Testar função de stats
  await testFunction('./netlify/functions/stats.js', mockEventSignals, 'Stats');
  
  // Testar função de templates
  await testFunction('./netlify/functions/templates.js', mockEventSignals, 'Templates');
  
  // Testar função CRON
  await testFunction('./netlify/functions/cron-signal-generator.js', mockEventCron, 'CRON Signal Generator');
  
  console.log('\n✅ All tests completed!');
}

// Executar testes
runTests().catch(console.error);