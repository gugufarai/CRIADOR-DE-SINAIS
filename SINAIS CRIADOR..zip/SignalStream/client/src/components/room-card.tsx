import { useState } from "react";
import { MessageCircle, Trash2, Send, Edit, Bomb, Dice6 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import EditRoomModal from "./edit-room-modal";
import type { SignalRoom } from "@shared/schema";

interface RoomCardProps {
  room: SignalRoom;
  onUpdate: () => void;
}

interface RoomStats {
  green: number;
  red: number;
  accuracy: number;
  lastSignal: string;
}

export default function RoomCard({ room, onUpdate }: RoomCardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  const { data: stats } = useQuery<RoomStats>({
    queryKey: ["/api/rooms", room.id, "stats"],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const deleteRoomMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/rooms/${room.id}`);
    },
    onSuccess: () => {
      toast({ title: "Sala excluída com sucesso!" });
      onUpdate();
      queryClient.invalidateQueries({ queryKey: ["/api/rooms"] });
    },
    onError: () => {
      toast({
        title: "Erro ao excluir sala",
        variant: "destructive",
      });
    },
  });

  const sendTestMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/rooms/${room.id}/test`);
    },
    onSuccess: () => {
      toast({ title: "Sinal de teste enviado!" });
    },
    onError: () => {
      toast({
        title: "Erro ao enviar sinal de teste",
        variant: "destructive",
      });
    },
  });

  const getSignalTypeIcon = () => {
    switch (room.signalType) {
      case 'mines':
        return <Bomb className="text-dark-bg" />;
      case 'bacbo':
        return <Dice6 className="text-dark-bg" />;
      default:
        return <MessageCircle className="text-dark-bg" />;
    }
  };

  const getSignalTypeColor = () => {
    switch (room.signalType) {
      case 'mines':
        return 'from-orange-accent to-orange-400';
      case 'bacbo':
        return 'from-green-accent to-green-400';
      default:
        return 'from-green-accent to-green-400';
    }
  };

  const handleDelete = () => {
    if (window.confirm(`Tem certeza que deseja excluir a sala "${room.name}"?`)) {
      deleteRoomMutation.mutate();
    }
  };

  const handleSendTest = () => {
    sendTestMutation.mutate();
  };

  return (
    <>
      <div className="bg-dark-bg border border-dark-border rounded-lg p-4" data-testid={`room-card-${room.id}`}>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-3">
            <div className={`w-10 h-10 bg-gradient-to-r ${getSignalTypeColor()} rounded-lg flex items-center justify-center`}>
              {getSignalTypeIcon()}
            </div>
            <div>
              <h3 className="font-semibold text-text-primary" data-testid={`text-room-name-${room.id}`}>
                {room.name}
              </h3>
              <p className="text-sm text-text-secondary">
                <span className="capitalize">{room.signalType}</span> • {room.gales} Gale{room.gales !== 1 ? 's' : ''}
                {room.signalType === 'mines' && room.minesAttempts && (
                  <span> • {room.minesAttempts} Tentativa{room.minesAttempts !== 1 ? 's' : ''}</span>
                )}
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Badge 
              variant={room.active ? "default" : "destructive"}
              className={room.active ? "bg-green-accent bg-opacity-20 text-green-accent" : "bg-red-accent bg-opacity-20 text-red-accent"}
              data-testid={`status-${room.id}`}
            >
              {room.active ? "Online" : "Pausado"}
            </Badge>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleDelete}
              disabled={deleteRoomMutation.isPending}
              className="text-text-secondary hover:text-red-accent"
              data-testid={`button-delete-${room.id}`}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
          <div className="text-center">
            <div className="text-xl font-bold text-green-accent" data-testid={`stat-green-${room.id}`}>
              {stats?.green || 0}
            </div>
            <div className="text-xs text-text-secondary">GREEN</div>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold text-red-accent" data-testid={`stat-red-${room.id}`}>
              {stats?.red || 0}
            </div>
            <div className="text-xs text-text-secondary">RED</div>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold text-text-primary" data-testid={`stat-accuracy-${room.id}`}>
              {stats?.accuracy || 0}%
            </div>
            <div className="text-xs text-text-secondary">ASSERTIVIDADE</div>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold text-orange-accent" data-testid={`stat-last-signal-${room.id}`}>
              {stats?.lastSignal || 'N/A'}
            </div>
            <div className="text-xs text-text-secondary">ÚLTIMO SINAL</div>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="text-sm text-text-secondary">Chat ID:</span>
            <code className="bg-dark-card px-2 py-1 rounded text-xs font-mono text-green-accent" data-testid={`text-chat-id-${room.id}`}>
              {room.chatId}
            </code>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              size="sm"
              onClick={handleSendTest}
              disabled={sendTestMutation.isPending}
              className="bg-green-accent hover:bg-green-400 text-dark-bg"
              data-testid={`button-test-${room.id}`}
            >
              <Send className="mr-1 h-3 w-3" />
              {sendTestMutation.isPending ? "Enviando..." : "Teste"}
            </Button>
            <Button
              size="sm"
              onClick={() => setIsEditModalOpen(true)}
              className="bg-orange-accent hover:bg-orange-400 text-dark-bg"
              data-testid={`button-edit-${room.id}`}
            >
              <Edit className="mr-1 h-3 w-3" />
              Editar
            </Button>
          </div>
        </div>
      </div>

      <EditRoomModal
        room={room}
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        onUpdate={onUpdate}
      />
    </>
  );
}
