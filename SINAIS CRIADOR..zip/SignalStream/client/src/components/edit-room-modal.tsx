import { useState, useEffect } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { SignalRoom } from "@shared/schema";

interface EditRoomModalProps {
  room: SignalRoom;
  isOpen: boolean;
  onClose: () => void;
  onUpdate: () => void;
}

export default function EditRoomModal({ room, isOpen, onClose, onUpdate }: EditRoomModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    name: room.name,
    gales: room.gales,
    active: room.active,
    minesAttempts: room.minesAttempts || 3,
  });

  useEffect(() => {
    setFormData({
      name: room.name,
      gales: room.gales,
      active: room.active,
      minesAttempts: room.minesAttempts || 3,
    });
  }, [room]);

  const updateRoomMutation = useMutation({
    mutationFn: async (data: Partial<SignalRoom>) => {
      const response = await apiRequest("PATCH", `/api/rooms/${room.id}`, data);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Sala atualizada com sucesso!" });
      onUpdate();
      onClose();
      queryClient.invalidateQueries({ queryKey: ["/api/rooms"] });
      queryClient.invalidateQueries({ queryKey: ["/api/rooms", room.id] });
    },
    onError: () => {
      toast({
        title: "Erro ao atualizar sala",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      toast({
        title: "Nome da sala é obrigatório",
        variant: "destructive",
      });
      return;
    }

    updateRoomMutation.mutate(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-dark-card border-dark-border text-text-primary max-w-md" data-testid="modal-edit-room">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            Editar Sala
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="text-text-secondary hover:text-text-primary"
              data-testid="button-close-edit-modal"
            >
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="editName" className="text-text-secondary">Nome da Sala</Label>
            <Input
              id="editName"
              data-testid="input-edit-room-name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="bg-dark-bg border-dark-border text-text-primary focus:border-green-accent focus:ring-green-accent"
            />
          </div>

          <div>
            <Label htmlFor="editGales" className="text-text-secondary">Quantidade de Gales</Label>
            <Select onValueChange={(value) => setFormData({ ...formData, gales: parseInt(value) })}>
              <SelectTrigger data-testid="select-edit-gales" className="bg-dark-bg border-dark-border text-text-primary focus:border-green-accent focus:ring-green-accent">
                <SelectValue placeholder={`${formData.gales} Gale${formData.gales !== 1 ? 's' : ''}`} />
              </SelectTrigger>
              <SelectContent className="bg-dark-card border-dark-border">
                <SelectItem value="0">Sem Gale</SelectItem>
                <SelectItem value="1">1 Gale</SelectItem>
                <SelectItem value="2">2 Gales</SelectItem>
                <SelectItem value="3">3 Gales</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {room.signalType === 'mines' && (
            <div>
              <Label htmlFor="editMinesAttempts" className="text-text-secondary">Tentativas para Mines</Label>
              <Select onValueChange={(value) => setFormData({ ...formData, minesAttempts: parseInt(value) })}>
                <SelectTrigger data-testid="select-edit-mines-attempts" className="bg-dark-bg border-dark-border text-text-primary focus:border-green-accent focus:ring-green-accent">
                  <SelectValue placeholder={`${formData.minesAttempts} Tentativa${formData.minesAttempts !== 1 ? 's' : ''}`} />
                </SelectTrigger>
                <SelectContent className="bg-dark-card border-dark-border">
                  <SelectItem value="1">1 Tentativa</SelectItem>
                  <SelectItem value="2">2 Tentativas</SelectItem>
                  <SelectItem value="3">3 Tentativas</SelectItem>
                  <SelectItem value="4">4 Tentativas</SelectItem>
                  <SelectItem value="5">5 Tentativas</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="flex items-center space-x-2">
            <Switch
              id="editActive"
              data-testid="switch-room-active"
              checked={formData.active}
              onCheckedChange={(checked) => setFormData({ ...formData, active: checked })}
              className="data-[state=checked]:bg-green-accent"
            />
            <Label htmlFor="editActive" className="text-text-secondary">Sala ativa</Label>
          </div>

          <div className="flex space-x-3">
            <Button 
              type="submit"
              data-testid="button-save-room-changes"
              disabled={updateRoomMutation.isPending}
              className="flex-1 bg-green-accent hover:bg-green-400 text-dark-bg font-semibold"
            >
              {updateRoomMutation.isPending ? "Salvando..." : "Salvar"}
            </Button>
            <Button 
              type="button"
              onClick={onClose}
              disabled={updateRoomMutation.isPending}
              className="flex-1 bg-dark-border hover:bg-gray-600 text-text-primary font-semibold"
              data-testid="button-cancel-edit"
            >
              Cancelar
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
