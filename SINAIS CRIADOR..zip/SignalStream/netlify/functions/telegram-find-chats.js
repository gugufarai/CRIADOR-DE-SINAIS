import TelegramService from '../../server/services/telegram.js';

const telegramService = new TelegramService();

export const handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    if (event.httpMethod === 'POST') {
      const body = JSON.parse(event.body);
      const { botToken } = body;

      if (!botToken) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ message: 'Bot token é obrigatório' })
        };
      }

      const chats = await telegramService.findAvailableChats(botToken.trim());
      
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(chats)
      };
    }

    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ message: 'Method not allowed' })
    };

  } catch (error) {
    console.error('❌ Error in telegram-find-chats function:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ message: 'Erro interno do servidor', error: error.message })
    };
  }
};